/* ------------ inicia coder.c ------------ */
/*
	coder.c
	-- ver 1.9
	-- genera "codigo", i.e. las coordenadas de la flechas
	
	Objeto: transformar una linea de texto en prefix y transformarla en una lista de "flechas",
		Con origen y destino. Las flechas son siempre horizontales y el origen es x1,y1, el final
		es x2, y2. y1 == y2 siempre.
		la entrada es algo como 
		"*a" 
		y la(s) salida(s) son:
		a,1,2,0,0  -- flecha para el terminal "a", de x1=1 a x2=2, en el nivel y1 = y2 = 0
		E,2,1,-1,-1  -- flecha para el terminal "" (épsilon) de x1=2 a x2=1, o sea, de REGRESO, en el nivel y1 = y2 = -1
		E,0,3,1,1  -- flecha para el terminal "" (épsilon) de x1=0 a x2=3, en el nivel y1 = y2 = 1
		
	input: recibe una linea en prefix
	output: texto con datos divididos por "," como se indica
		primer dato: terminal
		segundo dato: x1,
		tercer dato:  x2,
		cuarto dato:  y1,
		quinto dato:  y2
		
	Algoritmo:
		Se crea un nodo para cada token de entrada, digamos "|+ab*+cd", las flechas "->" indican el apuntador "draw"
			
					     "|" ->NULL
					   /     \
			  NULL<-"+"       *->NULL
				   /   \      |
       (0,1,0,0)<-a     b->   +->NULL       // para b->(0,1,0,0)
				             / \
				 (0,1,0,0)<-c   d->(0,1,0,0)
				            
		Cuando se crea, se genera para cada terminal un nodo tipo "arrow" con su localización, 
		siempre al inicio, x1=0, x2=1, y1=y2=0
		esta localización se va transformando conforme vamos "subiendo" por el arbol
		Para el símbolo
		"+": 
			el lado izquierdo->draw permanece intacto, 
			el lado derecho->draw se "mueve" a la derecha, al extremo del lado izquierdo, al final, 
			se concatenan y se pasan al campo "draw"

                                      "|" ->NULL
                                    /     \
            (1,2,0,0)<-(0,1,0,0)<-"+"       *->NULL
                                 /   \      |
                          NULL<-a     b->N  +->NULL      
                                           / \
                               (0,1,0,0)<-c   d->(0,1,0,0)
                           

		"|":
			el lado izq permanece intacto, 
			el lado derecho, el valor de las y1, y2 se incrementa
			al final se concatenan los nodos y se pasan al campro "draw" de "|"
			
		"*":
			sólo tiene una "patita", 
			se mueve lo que traiga en la patita, en el campo "draw", hacia la derecha,
			se agrega una flecha de regreso desde el final al principio
			se agrega una flecha "forward" desde un lugar antes del inicio a un lugar 
			despues del final.
			Al final se pasa todo esto al campo "draw" de "*"
	
		Al final, el nodo raíz, tiene todas las localizaciones de las flechas de terminales y las de los 
		"E", epsilons.
		
	-- revisión 20151202
		Se agrega reconocimiento y tratamiento de simbolo "+" como "una o más veces" de una regexp,
		por lo tanto se cambia el simbolo de concatenación a "-"
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>


#define STRSZ 256
#define setzero(a) memset((a), 0, sizeof((a)))
#define alfanum(a) \
(48 <= (a) && (a) <= 57) || (97 <= (a) && (a) <= 122) ? 1 : 0
#define mayor(a, b) ((a) < (b)) ? (b) : (a) 


char* p;


typedef struct arrow{
    char symbol;
    int x1, y1, x2, y2, state;
    struct arrow* next;
}arrow;


typedef struct node{
    char symbol;
    int width;
    int height;
    arrow* draw;
    struct node* left;
    struct node* right;
}node;


arrow* crea_arrow(char c)
{
    arrow* r = (arrow*)malloc(sizeof(arrow));
    if(!r){
        fprintf(stderr, "Out of memory\n");
        exit(0);
    }
    r->symbol = c;
    r->x1 = 0; r->x2 = 1;
    r->y1 = 0; r->y2 = 0;
    r->state = 0;
    r->next = NULL;

    return r;
}


node* crea_nodo()
{
    node* a = (node*)malloc(sizeof(node));
    if(!a){
        fprintf(stderr, "Out of memory\n");
        exit(0);
    }
    a->width = 0;
    a->height = 0;
    a->draw = NULL;
    a->left = NULL;
    a->right = NULL;

    return a;
}

void set_state(arrow** r, int rxmax, int ybase)
{
	arrow* m = (*r);
	while(m && m->next){ 
		if(m->x2 == rxmax && m->symbol != '~' && m->y2 == ybase){ /* hay algunos intermedios que van con circulo de state */
			m->state=1;
		}
		m = m->next; 
	}
	m->state=1;
	/*      */
}

int at_last(arrow** r, arrow** q)
{
	arrow* m = (*r);
	arrow* n = (*q);
	while(m && m->next) m = m->next;
    m->next = n;
    m = NULL;
    n = NULL;
}

imprime_lista(arrow* r)
{
	arrow* tmp = r;
	
    while(tmp){
        printf("%c,%d,%d,%d,%d,%d\n", tmp->symbol, tmp->x1, tmp->x2, tmp->y1, tmp->y2, tmp->state);
        tmp = tmp->next;
    }
}
	


int shift_right(arrow** r)
{
    arrow* q = (*r);
    while(q){ q->x1++; q->x2++; q = q->next; }

}

int extremos(arrow* r, int* x1, int* x2, int* y1, int* y2)
{
    arrow* r1 = r;

    (*x1) = 999; (*x2) = 0; (*y1) = 999; (*y2) = 0;

    while(r1){
        /* minimum x */
        if(r1->x1 < (*x1)) (*x1) = r1->x1;
        /* es necesario checar ambos por las flechas en reversa */
        if(r1->x2 < (*x1)) (*x1) = r1->x2;
        
        /* maximum x */
        if((*x2) < r1->x2) (*x2) = r1->x2;
        /* es necesario checar ambos por las flechas en reversa */
        if((*x2) < r1->x1) (*x2) = r1->x1;

        /* minimum */
        if(r1->y1 < (*y1)) (*y1) = r1->y1;
        /* maximum */
        if((*y2) < r1->y2) (*y2) = r1->y2;
        r1 = r1->next;
    }
}



arrow* crea_backarrow(arrow* r)
{
    int minimum, maximum, hminimum, hmaximum;
    arrow* q;
    arrow* m;

    q = crea_arrow('~');
    extremos(r, &minimum, &maximum, &hminimum, &hmaximum);

	/* flecha de regreso */
    q->x1 = maximum;
    q->x2 = minimum;
    q->y1 = q->y2 = --hminimum;
    
    /* flecha de subida */
    m = crea_arrow('~');
    m->x1 = maximum; /* hasta la derecha */
    m->x2 = maximum;
    m->y1 = r->y1; /* de la base line */
    m->y2 = hminimum; /* al inicio de la flecha bak */
    at_last(&q, &m);
    
    /* flecha de bajada */
    m = crea_arrow('~');
    m->x1 = minimum; /* hasta la izquierda */
    m->x2 = minimum;
    m->y1 = hminimum; /* hasta el final de la flecha fwd */
    m->y2 = r->y1; /* hasta la base line */
    at_last(&q, &m);
    
    return q;
    
}


arrow* plus_comple(arrow* r)
{
    int minimum, maximum, hminimum, hmaximum;
    arrow* q;
    arrow* m;

	extremos(r, &minimum, &maximum, &hminimum, &hmaximum);
	
    /* flecha complementaria izq */
    q = crea_arrow('~');
    q->x1 = minimum-1; /* hasta la izquierda */
    q->x2 = minimum; /* un solo paso */
    q->y1 = r->y1; /* nivel base line */
    q->y2 = r->y1; 
    q->state = 1;
	
    /* flecha complementaria der */
    m = crea_arrow('~');
    m->x1 = maximum; /* hasta la izquierda */
    m->x2 = maximum+1; /* un solo paso */
    m->y1 = r->y1; /* nivel base line */
    m->y2 = r->y1; 
    m->state = 1;
	at_last(&q, &m);
	
	return q;
}


arrow* crea_fwdarrow(arrow* r)
{
    int minimum, maximum, hminimum, hmaximum;
    arrow* q;
    arrow* m;

    q = crea_arrow('~');
    extremos(r, &minimum, &maximum, &hminimum, &hmaximum);
    q->x1 = --minimum;
    q->x2 = ++maximum;
    q->y1 = q->y2 = ++hmaximum;
	
    /* flecha de subida */
    m = crea_arrow('~');
    m->x1 = maximum; /* hasta la derecha */
    m->x2 = maximum;
    m->y1 = hmaximum; /* desde el final de la flecha fwd */
    m->y2 = r->y1; /* a las base line */
    at_last(&q, &m);
    
    /* flecha de bajada */
    m = crea_arrow('~');
    m->x1 = minimum; /* hasta la izquierda */
    m->x2 = minimum;
    m->y1 = r->y1; /* desde el base line */
    m->y2 = hmaximum; /* hasta el inicio de la flecha fwd */
    at_last(&q, &m);
	
    /* flecha complementaria izq */
    m = crea_arrow('~');
    m->x1 = minimum; /* hasta la izquierda */
    m->x2 = minimum+1; /* un solo paso */
    m->y1 = r->y1; /* nivel base line */
    m->y2 = r->y1; 
    m->state = 1;
    at_last(&q, &m);

    /* flecha complementaria der */
    m = crea_arrow('~');
    m->x1 = maximum-1; /* hasta la izquierda */
    m->x2 = maximum; /* un solo paso */
    m->y1 = r->y1; /* nivel base line */
    m->y2 = r->y1; 
    m->state = 1;
    at_last(&q, &m);
	
	return q;
}

int incrx(arrow** r, int incremento)
{
    arrow* q = (*r);
    while(q){
        q->x1 += incremento;
        q->x2 += incremento;
        q = q->next;
    }
}

int incry(arrow** r, int incremento, int xder, int ybase)
{
    arrow* q = (*r);
    while(q){
        q->y1 += incremento;
        q->y2 += incremento;
        /*
        printf(":%c,%d,%d,%d,%d,%d,[%d,%d]\n", q->symbol, q->x1, q->x2, q->y1, q->y2, q->state, xder, ybase);
        */
        if(q->x2 == xder){ /* si estamos a la extrema derecha */
        	q->state = 0;
        }
        /* hay algunos intermedios que van con circulo de state */
		/*
		if(m->x2 == rxmax && m->symbol != '~' && m->y2 == ybase){ 
			m->state=1;
		}
        */
        q = q->next;
    }   
}


int plus_arrows(node** a)
{
	arrow* b = NULL;
	arrow* lh = NULL;
	arrow* tmp = NULL;
	node* q = (*a);
	
	lh = q->left->draw;
	shift_right(&lh);
	
    b = crea_backarrow(lh);
	at_last(&lh, &b);
	b = NULL;
    
    b = plus_comple(lh);
    at_last(&lh, &b);
    
    q->draw = lh;
    lh = NULL;
    q->left->draw = NULL;
    b = NULL;
    q = NULL;
    
}

int asterisk_arrows(node** a)
{
	arrow* b = NULL;
	arrow* lh = NULL;
	arrow* tmp = NULL;
	node* q = (*a);
	
	lh = q->left->draw;
	shift_right(&lh);

    b = crea_backarrow(lh);
	at_last(&lh, &b);
    
    b = crea_fwdarrow(lh);
    at_last(&lh, &b);
    
    q->draw = lh;
    lh = NULL;
    q->left->draw = NULL;
    b = NULL;
    q = NULL;
}
	
int or_arrows(node** a)
{
    arrow* lh, *rh;
    int lxminimum, lxmaximum, lyminimum, lymaximum;
    int rxminimum, rxmaximum, ryminimum, rymaximum;
    int dif, rybase, lhbase;
    arrow* r = NULL;
    node* q = (*a);

    lh = q->left->draw;
    rh = q->right->draw;

    /* no dejamos cabos sueltos */
    q->left->draw = NULL;
    q->right->draw = NULL;

    q->draw = lh;
    extremos(lh, &lxminimum, &lxmaximum, &lyminimum, &lymaximum);
    extremos(rh, &rxminimum, &rxmaximum, &ryminimum, &rymaximum);
    dif = lymaximum-ryminimum+1;
    rybase = rh->y1;
    incry(&rh, dif, rxmaximum, rybase);
	
	if(lxmaximum < rxmaximum){ 
		/* la expresión de arriba es más corta que la de abajo */
		/* agregamos flecha para completar el circuito */
		r = crea_arrow('~');
		r->x1 = lxmaximum; 
		r->x2 = rxmaximum;
		r->y1 = lh->y1; /* el primer nodo tiene el nivel base */
		r->y2 = lh->y1;
		r->state = 1;
		at_last(&lh, &r);
	}else if(rxmaximum < lxmaximum){ 
		/* la expresión de abajo es más corta que la de arriba */

		/* el ultimo nodo de la pata derecha ya no va a ser el ultimo, entonces agregamos state */
		rybase = rh->y1;
		set_state(&rh, rxmaximum, rybase);

		/* agregamos flecha para completar el circuito */
		r = crea_arrow('~');
		r->x1 = rxmaximum; 
		r->x2 = lxmaximum;
		r->y1 = rh->y1; /* el primer nodo tiene el nivel base */
		r->y2 = rh->y1;
		at_last(&lh, &r);
	}
	at_last(&lh, &rh); /* al final de la pata izq agregamos lo de la pata der */	
	
	/* flecha de bajada */
	r = crea_arrow('~');
	r->x1 = lxminimum;
	r->x2 = lxminimum;
	r->y1 = lh->y1; /* el primer nodo tiene el nivel base */
	r->y2 = rh->y1; /* el primer nodo de la pata derecha tiene ahora el nivel base de esta expresión */
	at_last(&lh, &r);

	/* flecha de subida */
	r = crea_arrow('~');
	r->x1 = (lxmaximum < rxmaximum ? rxmaximum : lxmaximum); /* el que esté más hacia la derecha */
	r->x2 = (lxmaximum < rxmaximum ? rxmaximum : lxmaximum); /* el que esté más hacia la derecha */
	r->y1 = rh->y1; /* el primer nodo tiene el nivel base */
	r->y2 = lh->y1; /* el primer nodo de la pata derecha tiene ahora el nivel base de esta expresión */
	
	at_last(&lh, &r);

}

int add_arrows(node** a)
{
    arrow* lh, *rh, *tmp;
    int minimum, maximum, hminimum, hmaximum;
    int rminimum, rmaximum, rhminimum, rhmaximum;
    int dif;
    node* q = (*a);
    
    lh = q->left->draw;
    rh = q->right->draw;

    if(!lh){
    	fprintf(stderr, "error: no (+) left handle\n");
    	exit(0);
    }
    if(!rh){
    	fprintf(stderr, "error: no (+) right handle\n");
    	exit(0);
    }
    
    extremos(lh, &minimum, &maximum, &hminimum, &hmaximum);
    extremos(rh, &rminimum, &rmaximum, &rhminimum, &rhmaximum);
    dif = maximum-rminimum;
    incrx(&rh, dif);
	
	q->draw = lh;

	for(tmp = lh; tmp && tmp->next; tmp = tmp->next) ;
	tmp->next = rh;
	
    q->left->draw = NULL;
    q->right->draw = NULL;

}


node* crea_arbol(char* cad)
{
    char c;
    node* a = NULL;
    arrow* r = NULL;
    
    p = cad;
    if(!(*p)) return NULL;
    if((*p) == 10) return NULL; /* LF line feed */
    
    c = (*p++);

    a = crea_nodo();
    a->symbol = c;
    
    if(alfanum(c)){ /* terminal */
        a->width = 1;
        a->height = 0;
        r = crea_arrow(c);
        r->state = 1;
        a->draw = r;
    }else if(c == '*'){ /* cero o más veces */
        a->left = crea_arbol(p);
        a->width += 2;
        a->height += 2;
        asterisk_arrows(&a);
    }else if(c == '+'){ /* una o más veces */
        a->left = crea_arbol(p);
        a->width += 2;
        a->height += 2;
        plus_arrows(&a);
    }else if(c == '-'){ /* concatenación */
        a->left = crea_arbol(p);
        a->right = crea_arbol(p);
        a->width = a->left->width + a->right->width;
        a->height = mayor(a->left->height, a->right->height);
        add_arrows(&a);
    }else if(c == '|'){ /* una u otra expresión (OR) */
        a->left = crea_arbol(p);
        a->right = crea_arbol(p);
        a->width = mayor(a->left->width, a->right->width);
        a->height = a->left->height + a->right->height + 1;
        or_arrows(&a);
    }else{ /* error, simbolo desconocido */
        free(a);
        fprintf(stderr, "unknown symbol: %c [%d]\n", c, c);
        return NULL;
    }
	
    return a;
}


int free_arrow(arrow** r)
{
    arrow* q = (*r);
    while(q){
        q = q->next;
        free(*r);
        (*r) = q;
    }
}

free_arbol(node** a)
{
    node* q = (*a);

    if(!q) return;
    
    if(q->draw) free_arrow(&q->draw);
    if(q->left) free_arbol(&q->left);
    if(q->right) free_arbol(&q->right);
    
    q->draw = NULL;
    q->left = NULL;
    q->right = NULL;
    
    free(q);

    return 1;
}

int main(int argc, char* argv[])
{
    char linea[STRSZ];
    node* arbol = NULL;
	int first = 0; /* flag que indica primera linea */
	char original[STRSZ];
	int xmin = 0, xmax = 0, ymin = 0, ymax = 0;
	
	setzero(original);
	
    while(feof(stdin) == 0){
        setzero(linea);
        fgets(linea, STRSZ, stdin);
        if(linea[0] == 10 || linea[0] == 13) continue; /* saltarse lineas en blanco */
        /* detectar la primera linea pq viene en ella la cadena original, en infix */
        if(first){ /* no es primera línea */
	        /* procesamos */
	        if(arbol) free_arbol(&arbol);
	        arbol = crea_arbol(linea);
	        if(arbol && arbol->draw){ 
	        	printf("%s", original); 
	        	extremos(arbol->draw, &xmin, &xmax, &ymin, &ymax);
	        	printf("%d,%d\n", xmax, ymax-ymin);
	        	imprime_lista(arbol->draw); 
	        }
		}else{
			strcpy(original, linea);
			first++;
		}
        printf("\n");
    }

    if(arbol) free_arbol(&arbol);

    return 0;
}

/* ------------ finaliza coder.c ------------ */
