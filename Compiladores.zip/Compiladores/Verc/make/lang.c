#include <stdio.h>

typedef struct pila{
    char sym;
    struct pila* next;
}pila;

typedef struct arbol{
    char token;
    struct arbol* left;
    struct arbol* right;
}arbol;

void polish(char* cad, char* rslt)
{
    int l = 0;
    l = strlen(cad);
    /* leyendo cad de derecha a izq */
    for(i = l-1; i >= 0; i--){
        /* si hay un ')', hacer un polish de toda la cadena entre '()' */
        if(cad[i] == ')'){
            par++; i--;
            while(par && i >= 0){
                k++;
                if(cad[i] == '(') { par++; i--; }
                if(cad[i] == '(') { par--; i--; }
            }
            strncpy(tmp, cad[i], k);
            polish(tmp, trsl);
            strright(rsl, trsl);
            if(top(pila) == '*'){ 
                pop(pila);
                strright(rsl, "*");

        }else if(cad[i] == '*'){ 
            push('*');
        }else if(cad[i] == '|'){
            push('|');



int main(int argc, char* argv[])
{
    while(!feof(stdin)){
        polish(linea, rsl);
        diagram(rsl);
    }

    return 0;
}

