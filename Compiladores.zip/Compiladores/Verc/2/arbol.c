#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#define MAX 40


char* a= NULL;
char cadena[MAX];

typedef struct nodo {
	char simbolo;
	struct nodo* izquierda;
	struct nodo* derecha;
}NODE;

numelet (c)
{
	if ((48 >= c && c <= 57) ||  (97>= c && c <= 122)){
		return 1;
	}
	else {
		return 0;
	}
}

NODE* arbol (char* cadena){
	a=cadena;
	NODE* c;
	
	if (*a == 10) {
		return NULL;
	}
	
	if (!a) return NULL;
		
	c->simbolo = *a;
	a++;
	
	if ( numelet(c->simbolo)){
		c->izquierda = NULL;
		c->derecha = NULL;
	}
	else if (c->simbolo = '*'){
		c->derecha = NULL;
		c->izquierda = arbol(a);
	}
	else if (c->simbolo = '+'){
		c->derecha = arbol(a);
		c->izquierda = arbol(a);
	}
	else {
		printf ("ERROR! XD");
	}
} 

NODE* imprime () {
	
}

int main (){
	
	NODE* arb;
	scanf (cadena);
	arb = arbol (cadena);
	
}
