#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define STRSZ 256
#define setzero(a) memset((a), 0, sizeof((a)))
#define alfanum(a) \
(48 <= (a) && (a) <= 57) || (97 <= (a) && (a) <= 122) ? 1 : 0
#define mayor(a, b) ((a) < (b)) ? (b) : (a) 

char* p;

typedef struct arrow{
    int x1, y1;
    int x2, y2;

    struct arrow* next;
}arrow;

typedef struct node{
    char symbol;
    int width;
    int height;
    arrow* draw;
    struct node* left;
    struct node* right;
}node;


node* crea_arbol(char* cad);


arrow* crea_arrow()
{
    arrow* r = (arrow*)malloc(sizeof(arrow));
    r->x1 = 0; r->x2 = 1;
    r->y1 = 0; r->y2 = 0;
    r->next = NULL;

    return r;
}


node* crea_nodo()
{
    node* a = (node*)malloc(sizeof(node));
    if(!a){
        printf("Out of memory\n");
        exit(0);
    }
    a->width = 0;
    a->height = 0;
    a->draw = NULL;
    a->left = NULL;
    a->right = NULL;

    return a;
}

int shift_right(arrow** r)
{
    arrow* q = (*r);
    while(q){ q->x1++; q->x2++; q = q->next; }
}

int extremos(arrow* r, int* x1, int* x2, int* y1, int* y2)
{
    arrow* r1 = r;

    (*x1) = 999; (*x2) = 0; (*y1) = 999; (*y2) = 0;

    while(r1){
        /* minimum x */
        if(r1->x1 < (*x1)) (*x1) = r1->x1;
        /* es necesario checar ambos por las flechas en reversa */
        if(r1->x2 < (*x1)) (*x1) = r1->x2;
        
        /* maximum x */
        if((*x2) < r1->x2) (*x2) = r1->x2;
        /* es necesario checar ambos por las flechas en reversa */
        if((*x2) < r1->x1) (*x2) = r1->x1;

        /* minimum */
        if(r1->y1 < (*y1)) (*y1) = r1->y1;
        /* maximum */
        if((*y2) < r1->y2) (*y2) = r1->y2;
        r1++;
    }
}



int add_backarrow(arrow** r)
{
    int minimum, maximum, hminimum, hmaximum;
    arrow* q, *s = (*r);

    q = crea_arrow();
    extremos(s, &minimum, &maximum, &hminimum, &hmaximum);

    while(s){ s++; }
    s--;

    q->x1 = maximum;
    q->x2 = minimum;
    q->y1 = q->y2 = --hminimum;
    s->next = q;
}

int add_fwdarrow(arrow** r)
{
    int minimum, maximum, hmaximum, hminimum;
    arrow* q, *s = (*r);

    q = crea_arrow();
    while(s){ s++; }
    s--;

    extremos(s, &minimum, &maximum, &hmaximum, &hminimum);
    q->x1 = --minimum;
    q->x2 = ++maximum;
    q->y1 = q->y2 = ++hmaximum;
    s->next = q;
}

int incrx(arrow** r, int incremento)
{
    arrow* q = (*r);
    while(q){
        q->x1 += incremento;
        q->x2 += incremento;
        q = q->next;
    }
}

int incry(arrow** r, int incremento)
{
    arrow* q = (*r);
    while(q){
        q->y1 += incremento;
        q->y2 += incremento;
        q = q->next;
    }   
}

int add_arrows(node** a)
{
    arrow* lh, *rh;
    int minimum, maximum, hminimum, hmaximum;
    int rminimum, rmaximum, rhminimum, rhmaximum;
    int dif;
    node* q = (*a);
    
    lh = q->left->draw;
    rh = q->right->draw;
    q->draw = lh;
    extremos(lh, &minimum, &maximum, &hminimum, &hmaximum);
    extremos(rh, &rminimum, &rmaximum, &rhminimum, &rhmaximum);
    dif = maximum-rminimum;
    incrx(&rh, dif);
    while(lh) lh++; lh--;
    lh->next = rh;
}

int or_arrows(node** a)
{
    arrow* lh, *rh;
    int minimum, maximum, hminimum, hmaximum;
    int rminimum, rmaximum, rhminimum, rhmaximum;
    int dif;
    node* q = (*a);

    lh = q->left->draw;
    rh = q->right->draw;
    q->draw = lh;
    extremos(lh, &minimum, &maximum, &hminimum, &hmaximum);
    extremos(rh, &rminimum, &rmaximum, &rhminimum, &rhmaximum);
    dif = hmaximum-rhminimum;
    incry(&rh, dif);
    while(lh) lh++; lh--;
    lh->next = rh;

}


node* crea_arbol(char* cad)
{
    char c;
    node* a = NULL;
    arrow* r = NULL;
    
    p = cad;
    if(!(*p)) return NULL;
    if((*p) == 10) return NULL; /* LF line feed */
    
    c = (*p++);

    a = crea_nodo();
    a->symbol = c;
    if(alfanum(c)){ /* terminal */
        a->width = 1;
        r = crea_arrow();
        r->x2 = 1;
        a->draw = r;
    }else if(c == '*'){
        a->left = crea_arbol(p);
        a->width += 2;
        a->height += 2;
        shift_right(&(a->draw));
        add_backarrow(&(a->draw));
        add_fwdarrow(&(a->draw));
    }else if(c == '+'){
        a->left = crea_arbol(p);
        a->right = crea_arbol(p);
        a->width = a->left->width + a->right->width;
        a->height = mayor(a->left->height, a->right->height);
        add_arrows(&a);
    }else if(c == '|'){
        a->left = crea_arbol(p);
        a->right = crea_arbol(p);
        a->width = mayor(a->left->width, a->right->width);
        a->height = a->left->height + a->right->height;
        or_arrows(&a);
    }else{
        free(a);
        printf("unknown symbol: %c [%d]\n", c, c);
        return NULL;
    }

    return a;
}

int print_location(arrow* r)
{
    while(r){
        printf("xloc(%d, %d), ylevel(%d, %d)\n", r->x1, r->x2, \
                r->y1, r->y2);
        r++;
    }
}

int free_arrow(arrow** r)
{
    arrow* q = (*r);
    while(q){
        q = q->next;
        free(*r);
        (*r) = q;
    }
}

free_arbol(node** a)
{
    node* q = (*a);

    if(!q) return
        free_arrow(q->draw);
        free_arbol(&q->left);
        free_arbol(&q->right);
        free(q->left);
        free(q->right);
    }

    return 1;
}

int main(int argc, char* argv[])
{
    char linea[STRSZ];
    node* arbol = NULL;

    while(!feof(stdin)){
        setzero(linea);
        fgets(linea, STRSZ, stdin);
        printf("%s", linea);
        if(arbol) free_arbol(&arbol);
        arbol = crea_arbol(linea);
        if(arbol && arbol->draw){ print_location(arbol->draw); }
    }
    if(arbol) free_arbol(&arbol);

    return 0;
}

