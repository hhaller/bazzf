#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#define setzero(a) memset((a), 0, sizeof((a)))
#define TAM 512



int main (){
	char coordenadas[TAM];
	char* a;
	char temporal[3];
	int z[4];
	int i;

	while(feof(stdin) == 0){
		setzero(coordenadas);
		fgets(coordenadas, TAM, stdin);
		
		if (*a == 10) {
		return NULL;
		}
		if (!a) return NULL;
		
		a=coordenadas;
		
		i=0;
		while ((*a) && (*a)!=10){
			setzero(temporal);
			if((*a)==',') {
				a++;
			}
			temporal[0]=(*a);
			a++;
			if((*a)!=','){
			    temporal[1]=(*a);
				a++;
			}
			
			z[i]=atoi(temporal);
			i++; 
			//printf("%d-%c\n", i, *a);
			if(i == 4){
				printf("<line x1=\"%d\" y1=\"%d\" x2=\"%d\" y2=\"%d\" stroke=\"#855\" stroke-width=\"1\" stroke-linecap=\"round\" />\n", z[0], z[1], z[2], z[3]);
				i=0;
			}
		}
		
		
	}
}
