#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define STRSZ 256
#define setzero(a) memset((a), 0, sizeof((a)))
#define alfanum(a) \
(48 <= (a) && (a) <= 57) || (97 <= (a) && (a) <= 122) ? 1 : 0
#define mayor(a, b) ((a) < (b)) ? (b) : (a) 

char* p;

typedef struct arrow{
    char symbol;
    int x1, y1, x2, y2;
    struct arrow* next;
}arrow;

typedef struct node{
    char symbol;
    int width;
    int height;
    arrow* draw;
    struct node* left;
    struct node* right;
}node;


arrow* crea_arrow()
{
    arrow* r = (arrow*)malloc(sizeof(arrow));
    if(!r){
        fprintf(stderr, "Out of memory\n");
        exit(0);
    }
    r->x1 = 0; r->x2 = 1;
    r->y1 = 0; r->y2 = 0;
    r->next = NULL;

    return r;
}


node* crea_nodo()
{
    node* a = (node*)malloc(sizeof(node));
    if(!a){
        fprintf(stderr, "Out of memory\n");
        exit(0);
    }
    a->width = 0;
    a->height = 0;
    a->draw = NULL;
    a->left = NULL;
    a->right = NULL;

    return a;
}

int at_last(arrow** r, arrow** q)
{
	arrow* m = (*r);
	arrow* n = (*q);
	while(m && m->next) m = m->next;
    m->next = n;
    m = NULL;
    n = NULL;
}

imprime_lista(arrow* r)
{
	arrow* tmp = r;
	
    while(tmp){
        printf("%c,%d,%d,%d,%d\n", tmp->symbol, tmp->x1, tmp->x2, tmp->y1, tmp->y2);
        tmp = tmp->next;
    }
}
	


int shift_right(arrow** r)
{
    arrow* q = (*r);
    while(q){ q->x1++; q->x2++; q = q->next; }

}

int extremos(arrow* r, int* x1, int* x2, int* y1, int* y2)
{
    arrow* r1 = r;

    (*x1) = 999; (*x2) = 0; (*y1) = 999; (*y2) = 0;

    while(r1){
        /* minimum x */
        if(r1->x1 < (*x1)) (*x1) = r1->x1;
        /* es necesario checar ambos por las flechas en reversa */
        if(r1->x2 < (*x1)) (*x1) = r1->x2;
        
        /* maximum x */
        if((*x2) < r1->x2) (*x2) = r1->x2;
        /* es necesario checar ambos por las flechas en reversa */
        if((*x2) < r1->x1) (*x2) = r1->x1;

        /* minimum */
        if(r1->y1 < (*y1)) (*y1) = r1->y1;
        /* maximum */
        if((*y2) < r1->y2) (*y2) = r1->y2;
        r1 = r1->next;
    }
}



arrow* crea_backarrow(arrow* r)
{
    int minimum, maximum, hminimum, hmaximum;
    arrow* q;
    arrow* m;

    q = crea_arrow();
    extremos(r, &minimum, &maximum, &hminimum, &hmaximum);

	/* flecha de regreso */
	q->symbol = 'E';
    q->x1 = maximum;
    q->x2 = minimum;
    q->y1 = q->y2 = --hminimum;
    
    /* flecha de subida */
    m = crea_arrow();
    m->symbol = '^';
    m->x1 = maximum; /* hasta la derecha */
    m->x2 = maximum;
    m->y1 = r->y1; /* de la base line */
    m->y2 = hminimum; /* al inicio de la flecha bak */
    at_last(&q, &m);
    
    /* flecha de bajada */
    m = crea_arrow();
    m->symbol = 'V';
    m->x1 = minimum; /* hasta la izquierda */
    m->x2 = minimum;
    m->y1 = hminimum; /* hasta el final de la flecha fwd */
    m->y2 = r->y1; /* hasta la base line */
    at_last(&q, &m);
    
    return q;
    
}

arrow* crea_fwdarrow(arrow* r)
{
    int minimum, maximum, hminimum, hmaximum;
    arrow* q;
    arrow* m;

    q = crea_arrow();
    extremos(r, &minimum, &maximum, &hminimum, &hmaximum);
    q->symbol = 'E';
    q->x1 = --minimum;
    q->x2 = ++maximum;
    q->y1 = q->y2 = ++hmaximum;
	
    /* flecha de subida */
    m = crea_arrow();
    m->symbol = '^';
    m->x1 = maximum; /* hasta la derecha */
    m->x2 = maximum;
    m->y1 = hmaximum; /* desde el final de la flecha fwd */
    m->y2 = r->y1; /* a las base line */
    at_last(&q, &m);
    
    /* flecha de bajada */
    m = crea_arrow();
    m->symbol = 'v';
    m->x1 = minimum; /* hasta la izquierda */
    m->x2 = minimum;
    m->y1 = r->y1; /* desde el base line */
    m->y2 = hmaximum; /* hasta el inicio de la flecha fwd */
    at_last(&q, &m);
	
    /* flecha complementaria izq */
    m = crea_arrow();
    m->symbol = '<';
    m->x1 = minimum; /* hasta la izquierda */
    m->x2 = minimum+1; /* un solo paso */
    m->y1 = r->y1; /* nivel base line */
    m->y2 = r->y1; 
    at_last(&q, &m);

    /* flecha complementaria der */
    m = crea_arrow();
    m->symbol = '<';
    m->x1 = maximum-1; /* hasta la izquierda */
    m->x2 = maximum; /* un solo paso */
    m->y1 = r->y1; /* nivel base line */
    m->y2 = r->y1; 
    at_last(&q, &m);
	
	return q;
}

int incrx(arrow** r, int incremento)
{
    arrow* q = (*r);
    while(q){
        q->x1 += incremento;
        q->x2 += incremento;
        q = q->next;
    }
}

int incry(arrow** r, int incremento)
{
    arrow* q = (*r);
    while(q){
        q->y1 += incremento;
        q->y2 += incremento;
        q = q->next;
    }   
}

int asterisk_arrows(node** a)
{
	arrow* b = NULL;
	arrow* lh = NULL;
	arrow* tmp = NULL;
	node* q = (*a);
	
	lh = q->left->draw;
	shift_right(&lh);

    b = crea_backarrow(lh);
	at_last(&lh, &b);
    
    b = crea_fwdarrow(lh);
    at_last(&lh, &b);
    
    q->draw = lh;
    lh = NULL;
    q->left->draw = NULL;
    b = NULL;
    q = NULL;
}
	
int or_arrows(node** a)
{
    arrow* lh, *rh;
    int minimum, maximum, hminimum, hmaximum;
    int rminimum, rmaximum, rhminimum, rhmaximum;
    int dif;
    arrow* r = crea_arrow();
    node* q = (*a);

    lh = q->left->draw;
    rh = q->right->draw;

    q->draw = lh;
    extremos(lh, &minimum, &maximum, &hminimum, &hmaximum);
    extremos(rh, &rminimum, &rmaximum, &rhminimum, &rhmaximum);
    dif = hmaximum-rhminimum+1;
    incry(&rh, dif);
    at_last(&lh, &rh); /* al final de la para izq agregamos lo de la pata der */
    
    /* no dejamos cabos sueltos */
    q->left->draw = NULL;
    q->right->draw = NULL;
	
	/* flecha de bajada */
	r->symbol = 'E';
	r->x1 = minimum;
	r->x2 = minimum;
	r->y1 = lh->y1; /* el primer nodo tiene el nivel base */
	r->y2 = rh->y1; /* el primer nodo de la pata derecha tiene ahora el nivel base de esta expresión */
	at_last(&lh, &r);

	/* flecha de subida */
	r = crea_arrow();
	r->symbol = 'E';
	r->x1 = (maximum < rmaximum ? rmaximum : maximum); /* el que esté más hacia la derecha */
	r->x2 = (maximum < rmaximum ? rmaximum : maximum); /* el que esté más hacia la derecha */
	r->y1 = rh->y1; /* el primer nodo tiene el nivel base */
	r->y2 = lh->y1; /* el primer nodo de la pata derecha tiene ahora el nivel base de esta expresión */
	at_last(&lh, &r);

}

int add_arrows(node** a)
{
    arrow* lh, *rh, *tmp;
    int minimum, maximum, hminimum, hmaximum;
    int rminimum, rmaximum, rhminimum, rhmaximum;
    int dif;
    node* q = (*a);
    
    lh = q->left->draw;
    rh = q->right->draw;

    if(!lh){
    	fprintf(stderr, "error: no (+) left handle\n");
    	exit(0);
    }
    if(!rh){
    	fprintf(stderr, "error: no (+) right handle\n");
    	exit(0);
    }
    
    extremos(lh, &minimum, &maximum, &hminimum, &hmaximum);
    extremos(rh, &rminimum, &rmaximum, &rhminimum, &rhmaximum);
    dif = maximum-rminimum;
    incrx(&rh, dif);
	
	q->draw = lh;

	for(tmp = lh; tmp && tmp->next; tmp = tmp->next) ;
	tmp->next = rh;
	
    q->left->draw = NULL;
    q->right->draw = NULL;

}


node* crea_arbol(char* cad)
{
    char c;
    node* a = NULL;
    arrow* r = NULL;
    
    p = cad;
    if(!(*p)) return NULL;
    if((*p) == 10) return NULL; /* LF line feed */
    
    c = (*p++);

    a = crea_nodo();
    a->symbol = c;
    /* printf("proc %c(%d)\n", a->symbol, a->symbol); */
    if(alfanum(c)){ /* terminal */
        a->width = 1;
        r = crea_arrow();
        r->symbol = c;
        a->draw = r;
    }else if(c == '*'){
        a->left = crea_arbol(p);
        a->width += 2;
        a->height += 2;
        asterisk_arrows(&a);
    }else if(c == '+'){
        a->left = crea_arbol(p);
        a->right = crea_arbol(p);
        a->width = a->left->width + a->right->width;
        a->height = mayor(a->left->height, a->right->height);
        add_arrows(&a);
    }else if(c == '|'){
        a->left = crea_arbol(p);
        a->right = crea_arbol(p);
        a->width = mayor(a->left->width, a->right->width);
        a->height = a->left->height + a->right->height;
        or_arrows(&a);
    }else{
        free(a);
        fprintf(stderr, "unknown symbol: %c [%d]\n", c, c);
        return NULL;
    }
	
    return a;
}


int free_arrow(arrow** r)
{
    arrow* q = (*r);
    while(q){
        q = q->next;
        /* printf("lfree %c(%d)\n", (*r)->symbol, (*r)->symbol); */
        free(*r);
        (*r) = q;
    }
}

free_arbol(node** a)
{
    node* q = (*a);

    if(!q) return;
    
    if(q->draw) free_arrow(&q->draw);
    if(q->left) free_arbol(&q->left);
    if(q->right) free_arbol(&q->right);
    
    q->draw = NULL;
    q->left = NULL;
    q->right = NULL;
    
    /* printf("nfree %c(%d)\n", q->symbol, q->symbol); */
    free(q);

    return 1;
}

int main(int argc, char* argv[])
{
    char linea[STRSZ];
    node* arbol = NULL;

    while(feof(stdin) == 0){
        setzero(linea);
        fgets(linea, STRSZ, stdin);
        /* printf("cleaning tree\n"); */
        if(arbol) free_arbol(&arbol);
        arbol = crea_arbol(linea);
        if(arbol && arbol->draw){ imprime_lista(arbol->draw); }
        printf("\n");
    }

    if(arbol) free_arbol(&arbol);

    return 0;
}
