#include <stdlib.h>
#include <stdio.h>
#include "strgettok.h"

#define setzero(a) memset((a), 0, sizeof((a)))
#define STRSZ	256

/* Origen del grafo */
#define YZEROLINE 50
#define XZEROLINE 50

/* longitud de unidad */
#define XUNITY 50

/* longitud de nivel */
#define YUNITY 20

/* tamaño de cabeza de flecha */
#define XDELTA 10
#define YDELTA 5


int linea_svg(char* linea)
{
	char token[10], tmp[10];
	unsigned long indx = 0;
	int coord[4], i = 0;
	int x1, x2, y1, y2;

	char* p = linea;
	
	/* viene token,x1,x2,y1,y2 */
	/* si token = '0' indica fin de datos */
	
	if((*p) == 0) return 1;
	if((*p) == 10) return 1;
	if(!p) return 1;

	setzero(token);
	strgettok(linea, ",", &indx, token);
	for(i=0; i<4; i++){
		setzero(tmp);
		strgettok(linea, ",", &indx, tmp);
		coord[i] = atoi(tmp);
	}
	
	x1 = XZEROLINE+coord[0]*XUNITY;
	x2 = XZEROLINE+coord[1]*XUNITY;
	y1 = YZEROLINE+coord[2]*YUNITY;
	y2 = YZEROLINE+coord[3]*YUNITY;
	
	if(x1 < x2){ /* flecha hacia la derecha */
		/*
		x1 += XDELTA;
		x2 -= XDELTA;
		*/
		printf("<!-- %c: RH Arrow -->\n", *p);
		printf("<line x1=\"%d\" x2=\"%d\" y1=\"%d\" y2=\"%d\" stroke=\"#855\" stroke-width=\"1\" stroke-linecap=\"round\" />\n", x2, x2-XDELTA, y2, y2-YDELTA);
		printf("<line x1=\"%d\" x2=\"%d\" y1=\"%d\" y2=\"%d\" stroke=\"#855\" stroke-width=\"1\" stroke-linecap=\"round\" />\n", x2, x2-XDELTA, y2, y2+YDELTA);
		printf("\n");
	}else if(x2 < x1){ /* flecha hacia la izquierda */
		/*
		x1 -= XDELTA;
		x2 += XDELTA;
		*/
		printf("<!-- %c: LH Arrow -->\n", *p);
		printf("<line x1=\"%d\" x2=\"%d\" y1=\"%d\" y2=\"%d\" stroke=\"#855\" stroke-width=\"1\" stroke-linecap=\"round\" />\n", x2, x2+XDELTA, y2, y2-YDELTA);
		printf("<line x1=\"%d\" x2=\"%d\" y1=\"%d\" y2=\"%d\" stroke=\"#855\" stroke-width=\"1\" stroke-linecap=\"round\" />\n", x2, x2+XDELTA, y2, y2+YDELTA);
		printf("\n");
	}else if(y1 < y2){
		printf("<!-- %c: DW Arrow %d, %d, %d, %d -->\n", *p, x1, x2, y1, y2);
		printf("<line x1=\"%d\" x2=\"%d\" y1=\"%d\" y2=\"%d\" stroke=\"#855\" stroke-width=\"1\" stroke-linecap=\"round\" />\n", x2, x2+YDELTA, y2, y2-XDELTA);
		printf("<line x1=\"%d\" x2=\"%d\" y1=\"%d\" y2=\"%d\" stroke=\"#855\" stroke-width=\"1\" stroke-linecap=\"round\" />\n", x2, x2-YDELTA, y2, y2-XDELTA);
		printf("\n");
	}else if(y2 < y1){
		printf("<!-- %c: UP Arrow: %d, %d, %d, %d -->\n", *p, x1, x2, y1, y2);
		printf("<line x1=\"%d\" x2=\"%d\" y1=\"%d\" y2=\"%d\" stroke=\"#855\" stroke-width=\"1\" stroke-linecap=\"round\" />\n", x2, x2+YDELTA, y2, y2+XDELTA);
		printf("<line x1=\"%d\" x2=\"%d\" y1=\"%d\" y2=\"%d\" stroke=\"#855\" stroke-width=\"1\" stroke-linecap=\"round\" />\n", x2, x2-YDELTA, y2, y2+XDELTA);
		printf("\n");
	}			
	printf("<!-- %c: %d, %d, %d, %d -->\n", *p, x1, x2, y1, y2);
	printf("<line x1=\"%d\" x2=\"%d\" y1=\"%d\" y2=\"%d\" stroke=\"#855\" stroke-width=\"1\" stroke-linecap=\"round\" />\n", x1, x2, y1, y2);
	printf("\n");
	
	return 0;
}

	
	
	
	
int main(int argc, char* argv[])
{
	char linea[STRSZ];
	
	printf("<!DOCTYPE HTML>\n");
	printf("<html>\n");
	printf("<body>\n");
	printf("<svg xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" >\n");
	
	while(!feof(stdin)){
		setzero(linea);
		fgets(linea, STRSZ, stdin);
		linea_svg(linea);
	}

	printf("</svg>\n");
	printf("</body>\n");
	printf("</html>\n");
	
}
