/* ------------ inicia lexpar.c  ------------ */
/*
	lexpar.c
	-- ver 1.9
	-- lexer & parser
	
	Objetivo: 
		Convierte una string en infix en prefix, 
		libre de ambiguedades
		con prioridades y
		asociatividades implicitas aplicadas
		
	input: cadena en infix, por ejemplo, "ab|(cd)*"
	output: cadena en prefix, "|-ab*-cd"
	algoritmo:
		basado en el descrito en wikipedia: __https://en.wikipedia.org/wiki/Reverse_Polish_notation
		
	-- revisión 20151202
		Se agrega reconocimiento de simbolo "+", "una o más veces" de una expresión, por lo tanto se cambia
		el símbolo de concatenación a "-"
*/

		
#include <stdio.h>
#include <stdlib.h>

#define STRSZ 256


typedef struct{
    char cad[STRSZ];
    int indx;
}Stack;


void init(Stack* s);
int prefix(char* entrada, char* salida);
void push(Stack* s, char c);
char pop(Stack* s);
char top(Stack s);
char length(Stack s);
void display(Stack s);
int alfanum(char c);
void cleanvec(char* cad);


int main(int argc, char* argv[])
{
    char linea[STRSZ];
    char rsl[STRSZ];

    while(feof(stdin) == 0){
    	if(linea[0] == 10 || linea[0] == 13) continue; /* saltarse lineas en blanco */
        cleanvec(linea);
        cleanvec(rsl);

        fgets(linea, STRSZ, stdin);

        prefix(linea, rsl); 
        
        printf("%s%s", linea, rsl); /* regresamos la linea original y su representación en prefix */
    }
}


int prefix(char* entrada, char* salida)
{
    /* de notación infix a prefix */
    Stack pila, input, output, tmp;
    char* p = NULL, c, q;
    char rcad[STRSZ], trsl[STRSZ];
    int par=0, j=0, terminal=0, k=0;

    init(&pila);
    init(&input);
    init(&output);
    init(&tmp);
        
    /* primero pasamos la info a la pila para analizarla en sentido
     * contrario */
    for(p = entrada; *p; p++) { push(&input, *p); } 

    /* ahora analizamos cada elemento de la pila */
    while(length(input)){
        par = 0; j = 0;
        c = pop(&input);
        if(c == ')'){ /* es un parentesis, procesar recursivamente */
            par++;
            cleanvec(rcad); cleanvec(trsl); 
            for(j = 0; par && j < STRSZ; j++){
                c = pop(&input);
                if(c == ')'){
                	par++;
                	push(&tmp, c);
                }else if(c == '('){
                	par--;
                	if(par) push(&tmp, c);
                }else {
                	if(c) push(&tmp, c);
                }
            }
			if(par) { printf("unmatched parenthesis\n"); break; }
			
            /* hay que hacer esto para dejar la cadena en el
             * sentido correcto */
            for(j=0; length(tmp); j++) rcad[j] = pop(&tmp);

            /* llamada recursiva */
            /* printf("rcad: %s\n", rcad); */
            prefix(rcad, trsl);
			/* printf("trsl: %s\n", trsl); */
			
            /* en trsl viene el resultado, hay que tratarlo
             * como un terminal */
            terminal++;
            /* la cadena viene en sentido directo, hay que 
             * reversarla y colocarla <<tal cual>> en la salida */
            init(&tmp); k = 0;
            for(p=trsl; *p; p++) { push(&tmp, *p); k++; }
            for(; k>0; k--) { q = pop(&tmp); if(q) push(&output, q); }
            
            /* aquí se implementa la prioridad */
            if(top(pila) == '*' || top(pila) == '+'){ q = pop(&pila); if(q) push(&output, q); }
            if(terminal > 1) push(&pila, '-');
        }else if(c == '*'){
            /* unary asterisk, highest priority */
            push(&pila, c);
        }else if(c == '+'){
            /* unary asterisk, highest priority */
            push(&pila, c);
        }else if(c == '|'){
            /* binary pipe, lowest priority */
            while(top(pila) == '+') { push(&output, pop(&pila)); }
            push(&pila, c);
            terminal = 0;
        }else if(alfanum(c)){
            terminal++;
            push(&output, c);
            /* aqui se implementa la prioridad */
            if(top(pila) == '*' || top(pila) == '+') push(&output, pop(&pila));
            if(terminal > 1) push(&pila, '-');
        }else if(c == 10){
        	/* nada */
        }else if(c == '('){
        	printf("unmatched parenthesis\n"); 
        	break;
        }else{
        	printf("unrecognized char '%c' [%d]\n", c, c);
        	break;
        }
    }

    /* si hay algo en la pila, agregarlo en la salida */
    while(length(pila)){ 
    	q = pop(&pila);
    	if(q) push(&output, q); 
    }

    /* al final, se pasa lo que hay en output a la cadena de resultado */
    for(j=0; length(output); j++){
    	salida[j] = pop(&output);
    }

}

void push(Stack* s, char c){ (*s).cad[(*s).indx++] = c; }
char pop(Stack* s){ if((*s).indx) return (*s).cad[--(*s).indx]; }
char top(Stack s){ if(s.indx) return s.cad[s.indx-1]; }
char length(Stack s){ return s.indx; }
void display(Stack s){ printf("%s\n", s.cad); }
int alfanum(char c) 
{  
	if( (48 <= c && c <= 57) || (97 <= c && c <= 122) ) return 1; 
    else return 0; 
}
void cleanvec(char* cad)
{
    int i = 0;
    for(i = 0; i < STRSZ; i++) cad[i] = '\0';
}

void init(Stack* s){ cleanvec((*s).cad); (*s).indx = 0; }
/* ------------ finaliza lexpar.c ------------ */
