#include "strgettok.h"

#ifdef __cplusplus
extern "C"
#endif
int isdelim(char c, char* delim)
{

/*

	verifies if char c is a	subset of chars	in delim

*/

	char* p;
	int flag;



	flag = 0;
	for(p=delim; (*p) && !flag; p++){
		if(c ==	(*p)) flag = 1;
	}

	return flag;

}

#ifdef __cplusplus
extern "C"
#endif
int strgettok(char* str, char* delim, long* index, char* rsl)
{

char* p;
int idx, i;

	if(strlen(delim) < 1){ /* there	are no delimiters */

		/* copying the token to	the rsl	variable */
		strcpy(rsl, str);
		(*index) = strlen(str)+1;

		return 0;
	}	

	if((unsigned int)(*index) > strlen(str)) strcpy(rsl, ""); /* no	more tokens */

	/* skipping heading delimiters */
	for(p=&str[*index];(*p)	&& isdelim(*p, delim); p++, (*index)++); 

	/* printf("heading delimiters skipped"); */

	/* after skipping heading delimiters could happen that there are no more tokens	*/
	if(!(*p)) strcpy(rsl, "");

	/* printf("there are more tokens, index: %d",	(*index)); */

	/* this	is the token -from idx to index- */
	for(idx	= (*index); *p && !isdelim(*p, delim); p++, (*index)++);

	/* printf("len token: %d", (*index)-idx); */

	/* copying the token to	the rsl	variable */
	for(i=0; i < ((*index)-idx); i++) rsl[i] = str[idx+i];

	rsl[(*index)-idx] = '\0';  /* ending the string	*/

	/* printf("token: %s", q); */
	return 0;
}
