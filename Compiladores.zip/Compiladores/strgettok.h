#ifndef __STRGETTOK_H__
#define __STRGETTOK_H__
#include <string.h>
int isdelim(char c, char* delim);
int strgettok(char* str, char* delim, long* index, char* rsl);
#endif /* __STRGETTOK_H__ */
