/* ------------ inicia grapher.c  ------------ */
/*
	grapher.c
	-- ver 1.9
	-- graficador
	
	Objetivo: 
		convierte bloques de 6 datos 
		en flechas dibujadas usando notación SVG
		
			a,0,1,0,0,1   // token, x1, x2, y1, y2, state
			token de transición de estado
			coordenadas de la flecha, x1 e y1  es el inicio
			coordenadas de la flecha, x2 e y2  es el final de la flecha
			state es un indicador de si se dibuja circulo de estado o no.
		
	
	input: bloques de datos
		a,0,1,0,0,1
		b,1,2,0,0,0
		.
		.
		.
		
	output: archivo SVG (html).

	revision:
	-- Con colores diferentes para las trayectorias FWD y las de retorno
	-- Usa curvas para las flechas de bajada y subida de flechas fwd
	-- Usa curvas para las flechas de bajada y subida de flechas back
			
	Faltantes:
		Casos de prueba:
		ver archivo DAT, casos de uso		
		
		-- Falta ordenar los estados, se vería mejor incrementar de izq a der y del nivel 0 a los siguientes
*/

#include <stdio.h>
#include <stdlib.h>
#include "strgettok.h"

#define setzero(a) memset((a), 0, sizeof((a)))
#define STRSZ	256
#define RADIO 10

/* Origen del grafo */
#define YZEROLINE 100
#define XZEROLINE 50

/* longitud de unidad */
#define XUNITY 120

/* longitud de nivel */
#define YUNITY 24

/* tamaño de cabeza de flecha */
#define XDELTA 4
#define YDELTA 4

/* reducir la longitud de la flecha en */
#define XREDUX 10
#define YREDUX 8

/* tamaño de curva esquina */
#define XESQ 10
#define YESQ 10

/* color de linea */
#define FWDCOLOR "303D4E"
#define BCKCOLOR "823E35"

#define RHEAD 1
#define LHEAD -1

typedef struct{
	int coord[3][STRSZ];
	int indx;
}PILA;

enum{
	LH = 0, RH
};

enum{
	ADIR = 0, X1, X2, Y1, Y2 /* direccion y coordenadas de la flecha */
};

int harrow[5]; /* ultima flecha horizontal */

/* ancho y alto del grafo */
int graphwidth = 0;
int grapheight = 0;

PILA s; /* pila de estados */
int nst = 1; /* numero de estado */


void push(PILA* s, int x, int y)
{ 
	(*s).coord[1][(*s).indx] = x; 
	(*s).coord[2][(*s).indx] = y; 
	(*s).indx++;
}

void arrow_header(int x1, int y, int x2, int sentido)
{
	int pmedio = (x1+x2)/2;
	if(sentido == RHEAD){
		printf("<line x1=\"%d\" x2=\"%d\" y1=\"%d\" y2=\"%d\" stroke=\"#303D4E\" stroke-width=\"2\" stroke-linecap=\"round\" />\n", pmedio, pmedio-XDELTA, y, y-YDELTA);
		printf("<line x1=\"%d\" x2=\"%d\" y1=\"%d\" y2=\"%d\" stroke=\"#303D4E\" stroke-width=\"2\" stroke-linecap=\"round\" />\n", pmedio, pmedio-XDELTA, y, y+YDELTA);
	}else{	
		printf("<line x1=\"%d\" x2=\"%d\" y1=\"%d\" y2=\"%d\" stroke=\"#823E35\" stroke-width=\"2\" stroke-linecap=\"round\" />\n", pmedio, pmedio+XDELTA, y, y-YDELTA);
		printf("<line x1=\"%d\" x2=\"%d\" y1=\"%d\" y2=\"%d\" stroke=\"#823E35\" stroke-width=\"2\" stroke-linecap=\"round\" />\n", pmedio, pmedio+XDELTA, y, y+YDELTA);
	}
}

void right_arrow(int x1, int x2, int y, char c)
{
	printf("<!-- %c: RH Arrow -->\n", c);
	printf("<!-- %c: %d, %d, %d, %d -->\n", c, x1, x2, y, y);
	arrow_header(x1, y, x2, RHEAD);
	printf("<line x1=\"%d\" x2=\"%d\" y1=\"%d\" y2=\"%d\" stroke=\"#303D4E\" stroke-width=\"2\" stroke-linecap=\"round\" />\n", x1, x2, y, y);
	printf("\n");
}

void left_arrow(int x1, int x2, int y, char c)
{
	printf("<!-- %c: LH Arrow -->\n", c);
	printf("<!-- %c: %d, %d, %d, %d -->\n", c, x1, x2, y, y);
	arrow_header(x1, y, x2, LHEAD);
	printf("<line x1=\"%d\" x2=\"%d\" y1=\"%d\" y2=\"%d\" stroke=\"#823E35\" stroke-width=\"2\" stroke-linecap=\"round\" />\n", x1, x2, y, y);
	printf("\n");
}
	
int linea_svg(char* linea)
{
	char token[10], tmp[10];
	unsigned long indx = 0;
	int coordenadas[5], i = 0;
	int state; /* circulo de estado */
	int x1, x2, y1, y2;
	int xini1, yini1, xini2, yini2;
	char* p = linea;
	
	/* viene token,x1,x2,y1,y2,estado */
	
	if((*p) == 0) return 1;
	if((*p) == 10) return 1;
	if(!p) return 1;

	setzero(token);
	strgettok(linea, ",", &indx, token);
	for(i=0; i<5; i++){
		setzero(tmp);
		strgettok(linea, ",", &indx, tmp);
		coordenadas[i] = atoi(tmp);
	}
	
	x1 = XZEROLINE+coordenadas[0]*XUNITY;
	x2 = XZEROLINE+coordenadas[1]*XUNITY;
	y1 = YZEROLINE+coordenadas[2]*YUNITY;
	y2 = YZEROLINE+coordenadas[3]*YUNITY;
	state = coordenadas[4];
	
	xini1 = x1; yini1 = y1; xini2 = x2; yini2 = y2;
	if(x1 < x2){ /* flecha hacia la derecha */
		harrow[ADIR] = RH;
		harrow[X1] = x1;
		harrow[X2] = x2;
		harrow[Y1] = y1;
		harrow[Y2] = y2;

		if(state){
			push(&s, x2, y2);
		}

		x1 += XREDUX; x2 -= XREDUX; /* acortamos el tamaño de la linea para mejor efecto visual*/
		right_arrow(x1, x2, y1, *p);
		/* el token, sólo tiene sentido en las flechas horizontales */
		printf("<!-- %s: %d, %d, %d, %d -->\n", token, x1, x2, y1, y2);
		printf("<text x=\"%d\" y=\"%d\">%s</text>\n", (x1+x2)/2, (y1+y2)/2, token);
	}else if(x2 < x1){ /* flecha hacia la izquierda */
		harrow[ADIR] = LH;
		harrow[X1] = x1;
		harrow[X2] = x2;
		harrow[Y1] = y1;
		harrow[Y2] = y2;
		x1 -= XREDUX; x2 += XREDUX; /* acortamos el tamaño de la linea para mejor efecto visual*/
		left_arrow(x1, x2, y1, *p);
		/* el token, sólo tiene sentido en las flechas horizontales */
		printf("<!-- %s: %d, %d, %d, %d -->\n", token, x1, x2, y1, y2);
		printf("<text x=\"%d\" y=\"%d\">%s</text>\n", ((x1+x2)/2)-XREDUX, (y1+y2)/2, token);
	}else if(y1 < y2){
		/* flecha hacia abajo */
		printf("<!-- %c: DW Arrow %d, %d, %d, %d -->\n", *p, x1, x2, y1, y2);
		if(harrow[ADIR] == LH){
			/*	la flecha lider fue a la izquierda, es una flecha de regreso */
			/* las curvas de las esquinas */
			printf("<!-- %c: %d, %d, %d, %d -->\n", *p, x1, x2, y1, y2);
			printf("<path d=\"M %d %d Q %d %d %d %d\" stroke=\"#823E35\" stroke-width=\"2\" stroke-linecap=\"round\" style=\"fill: none\";/>\n", x1+XESQ, y1, x1, y1, x1, y1+YESQ);
			y1 += YREDUX; y2 -= YREDUX;
			/* finalmente la linea acortada */
			printf("<line x1=\"%d\" x2=\"%d\" y1=\"%d\" y2=\"%d\" stroke=\"#823E35\" stroke-width=\"2\" stroke-linecap=\"round\" />\n", x1, x2, y1, y2);
		}else{
			/* flecha lider hacia la derecha */
			/* las curvas de las esquinas */
			printf("<path d=\"M %d %d Q %d %d %d %d\" stroke=\"#303D4E\" stroke-width=\"2\" stroke-linecap=\"round\" style=\"fill: none\";/>\n", x2, y2-YESQ, x2, y2, x2+XESQ, y2);
			y1 -= YREDUX;
			y2 -= YREDUX;
			/* finalmente la linea acortada */
			printf("<line x1=\"%d\" x2=\"%d\" y1=\"%d\" y2=\"%d\" stroke=\"#303D4E\" stroke-width=\"2\" stroke-linecap=\"round\" />\n", x1, x2, y1, y2);
		}
		printf("\n");
	}else if(y2 < y1){
		/* flecha hacia arriba */
		printf("<!-- %c: UP Arrow: %d, %d, %d, %d -->\n", *p, x1, x2, y1, y2);
		if(harrow[ADIR] == LH){
			/*	la flecha lider fue a la izquierda, es una flecha de regreso */
			/* dibujamos un semi-circulo */
			printf("<!-- %c: %d, %d, %d, %d -->\n", *p, x1, x2, y1, y2);
			printf("<path d=\"M %d %d Q %d %d %d %d\" stroke=\"#823E35\" stroke-width=\"2\" stroke-linecap=\"round\" style=\"fill: none\";/>\n", x2, y2+YESQ, x2, y2, x2-XESQ, y2);
			y1 -= YREDUX; y2 += YREDUX;
			printf("<line x1=\"%d\" x2=\"%d\" y1=\"%d\" y2=\"%d\" stroke=\"#823E35\" stroke-width=\"2\" stroke-linecap=\"round\" />\n", x1, x2, y1, y2);
		}else{
			/* flecha lider hacia la derecha */
			/* las curvas de las esquinas */
			printf("<path d=\"M %d %d Q %d %d %d %d\" stroke=\"#303D4E\" stroke-width=\"2\" stroke-linecap=\"round\" style=\"fill: none\";/>\n", x1-XESQ, y1, x1, y1, x1, y1-YESQ);
			y1 -= YREDUX; 
			y2 -= YREDUX;
			if(y2 == YZEROLINE){ y2 += YREDUX; }
			printf("<line x1=\"%d\" x2=\"%d\" y1=\"%d\" y2=\"%d\" stroke=\"#303D4E\" stroke-width=\"2\" stroke-linecap=\"round\" />\n", x1, x2, y1, y2);
		}
		printf("\n");
	}
	printf("\n");
	
	
	return 0;
}

void print_states(PILA s)
{
	int x, y, i = 0;

	

	for(i = 0; i < s.indx; i++){
		x = s.coord[1][i];
		y = s.coord[2][i];
		printf("<circle cx=\"%d\", cy=\"%d\", r=\"%d\" stroke=\"#303D4E\" stroke-width=\"1\" fill=\"white\" />\n", x, y, RADIO);
		if(x == graphwidth && y == YZEROLINE){
			/* ultimo nodo, terminal */
		}else{
			printf("<text x=\"%d\" y=\"%d\">S%d</text>\n", x-8, y+6, nst++);
		}
	}
	/* primer estado, inicial */
	printf("<circle cx=\"%d\", cy=\"%d\", r=\"%d\" stroke=\"#303D4E\" stroke-width=\"1\" fill=\"white\" />\n", XZEROLINE, YZEROLINE, RADIO);
	printf("<text x=\"%d\" y=\"%d\">S</text>\n", XZEROLINE-5, YZEROLINE+6, nst++);

	/* ultimo estado, terminal */
	printf("<circle cx=\"%d\", cy=\"%d\", r=\"%d\" stroke=\"#303D4E\" stroke-width=\"1\" fill=\"white\" />\n", graphwidth, YZEROLINE, RADIO);
	printf("<circle cx=\"%d\", cy=\"%d\", r=\"%d\" stroke=\"#303D4E\" stroke-width=\"1\" fill=\"white\" />\n", graphwidth, YZEROLINE, RADIO/2);
	
	/* linea de start */
	printf("<!-- start line -->\n");
	printf("<line x1=\"%d\" x2=\"%d\" y1=\"%d\" y2=\"%d\" stroke=\"black\" stroke-width=\"2\" stroke-linecap=\"round\" />\n", XZEROLINE-10, (XZEROLINE-10)-XDELTA, YZEROLINE, YZEROLINE-YDELTA);
	printf("<line x1=\"%d\" x2=\"%d\" y1=\"%d\" y2=\"%d\" stroke=\"black\" stroke-width=\"2\" stroke-linecap=\"round\" />\n", XZEROLINE-10, (XZEROLINE-10)-XDELTA, YZEROLINE, YZEROLINE+YDELTA);
	printf("<line x1=\"%d\" x2=\"%d\" y1=\"%d\" y2=\"%d\" stroke=\"black\" stroke-width=\"2\" stroke-linecap=\"round\" />\n", 0, XZEROLINE-10, YZEROLINE, YZEROLINE);
	
}
	
int main(int argc, char* argv[])
{
	char linea[STRSZ];
	char medida[STRSZ];
	int lineno = 1;
	int w, h;
	long indx = 0;
	
	printf("<!DOCTYPE html>\n");
	printf("<html>\n");
	printf("<head>\n");
	printf("<title>Graficador</title>\n");
	printf("</head>\n");
	printf("<body>\n");


	setzero((void*)&s); /* limpiamos la pila */
	while(!feof(stdin)){
		setzero(linea);
		fgets(linea, STRSZ, stdin);
		if(linea[0] == 10 || linea[0] == 13) continue; /* saltarse lineas en blanco */
		if(lineno == 1){ /* expresion original en infix */
			printf("<h2>%s</h2>\n", linea);
			lineno++;
		}else if(lineno == 2){ /* ancho y alto del grafo */
			setzero(medida);
			strgettok(linea, ",", &indx, medida);
			graphwidth = atoi(medida);
			w = graphwidth;
			graphwidth = XZEROLINE + graphwidth * XUNITY;
			setzero(medida);
			strgettok(linea, ",", &indx, medida);
			grapheight = atoi(medida);
			h = grapheight;
			grapheight = YZEROLINE + grapheight * YUNITY;
			
			printf("<!-- graphwidth: %d; grapheight: %d -->\n", w, h);
			printf("<svg xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" width=\"%d\" height=\"%d\">\n", graphwidth+RADIO+2, grapheight+RADIO+2);	
			lineno++;
		}else{
			linea_svg(linea);
		}
	}
	print_states(s);
	printf("</svg>\n");
	printf("</body>\n");
	printf("</html>\n");
	
}
		
/* ------------ finaliza grapher.c  ------------ */
